#include "katutaso.h"

void Katutaso::maaritaAsunnot()
{
    cout <<"*Maaritetaan katutason asuntoja*"<< endl;
}
