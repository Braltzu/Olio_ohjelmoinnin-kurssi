#include "kerros.h"

void Kerros::maaritaAsunnot()
{
    cout <<"*Maaritetaan kerroksen asuntoja*"<< endl;
}
