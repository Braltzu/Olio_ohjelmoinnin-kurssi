#include <iostream>
#include "Game.h"
using namespace std;

int main()
{
    Game gameObject(10);
    gameObject.play();
    return 0;
}
